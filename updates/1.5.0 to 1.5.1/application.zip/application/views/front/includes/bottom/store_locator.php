			
			<script type="text/javascript">
				var base_url = '<?php echo base_url(); ?>';
			</script>
			<script type="text/javascript" src="<?php echo base_url(); ?>template/front/js/mapcluster.js"></script>